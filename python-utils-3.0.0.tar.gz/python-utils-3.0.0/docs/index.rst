Welcome to Python Utils's documentation!
========================================

.. image:: https://github.com/WoLpH/python-utils/actions/workflows/main.yml/badge.svg?branch=master
  :target: https://github.com/WoLpH/python-utils/actions/workflows/main.yml/badge.svg?branch=master

.. image:: https://coveralls.io/repos/WoLpH/python-utils/badge.svg?branch=master
  :target: https://coveralls.io/r/WoLpH/python-utils?branch=master

Contents:

.. toctree::
   :maxdepth: 4

   usage
   python_utils

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

